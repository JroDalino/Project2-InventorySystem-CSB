<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Products</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="sidebar">
    <h1>Inventory</h1>
    <a href="dashboard.jsp">Dashboard</a>
    <a href="product.jsp">Product</a>
    <a href="order.jsp">Order</a>
    <a href="supplier.jsp">Supplier</a>
    <a href="profile.jsp">Profile</a>
</div>

<div class="main">
    <div class="header">
        <div class="title">
            <h1>Products</h1>
        </div>
        <div class="search-box">
            <span>&#128269;</span>
            <input type="text" placeholder="Search">
        </div>
    </div>

    <div class="filters">
        <select id="priceFilter">
            <option value="">Sort by Price</option>
            <option value="low-high">Min to Max</option>
            <option value="high-low">Max to Min</option>
        </select>
        <select id="sizeFilter">
            <option value="">Size</option>
            <option value="XS">XS</option>
            <option value="S">S</option>
            <option value="M">M</option>
            <option value="L">L</option>
            <option value="XL">XL</option>
        </select>
        <select id="categoryFilter">
            <option value="">Category</option>
            <option value="top">Top</option>
            <option value="bottom">Bottom</option>
            <option value="skirt">Skirt</option>
            <option value="accessory">Accessory</option>
            <option value="footwear">Footwear</option>
        </select>
    </div>

    <div class="product-grid">
        <div class="product-card" data-price="12.99" data-size="M" data-category="top">
            <img src="images/flower1.jpg" alt="Classic Top" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect width=%22300%22 height=%22200%22 fill=%22%23f8dddd%22/%3E%3Ctext x=%22150%22 y=%22100%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22%23d12061%22%3EClassic Top%3C/text%3E%3C/svg%3E'">
            <div class="actions"><div>add</div><div>add to cart</div><div>delete</div></div>
            <div class="info">
                <h4>Classic Top</h4>
                <div class="price">$12.99</div>
                <div class="quantity">quantity= 50</div>
                <div class="producttype">Product Type: Top</div>
                <div class="productsize">Product Size: M</div>
            </div>
        </div>

        <div class="product-card" data-price="15.99" data-size="S" data-category="bottom">
            <img src="images/flower2.jpg" alt="Casual Bottom" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect width=%22300%22 height=%22200%22 fill=%22%23f8dddd%22/%3E%3Ctext x=%22150%22 y=%22100%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22%23d12061%22%3ECasual Bottom%3C/text%3E%3C/svg%3E'">
            <div class="actions"><div>add</div><div>add to cart</div><div>delete</div></div>
            <div class="info">
                <h4>Casual Bottom</h4>
                <div class="price">$15.99</div>
                <div class="quantity">quantity= 30</div>
                <div class="producttype">Product Type: Bottom</div>
                <div class="productsize">Product Size: S</div>
            </div>
        </div>

        <div class="product-card" data-price="10.99" data-size="L" data-category="skirt">
            <img src="images/flower3.jpg" alt="Summer Skirt" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect width=%22300%22 height=%22200%22 fill=%22%23f8dddd%22/%3E%3Ctext x=%22150%22 y=%22100%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22%23d12061%22%3ESummer Skirt%3C/text%3E%3C/svg%3E'">
            <div class="actions"><div>add</div><div>add to cart</div><div>delete</div></div>
            <div class="info">
                <h4>Summer Skirt</h4>
                <div class="price">$10.99</div>
                <div class="quantity">quantity= 45</div>
                <div class="producttype">Product Type: Skirt</div>
                <div class="productsize">Product Size: L</div>
            </div>
        </div>

        <div class="product-card" data-price="8.99" data-size="XS" data-category="accessory">
            <img src="images/flower4.jpg" alt="Cute Accessory" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect width=%22300%22 height=%22200%22 fill=%22%23f8dddd%22/%3E%3Ctext x=%22150%22 y=%22100%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22%23d12061%22%3ECute Accessory%3C/text%3E%3C/svg%3E'">
            <div class="actions"><div>add</div><div>add to cart</div><div>delete</div></div>
            <div class="info">
                <h4>Cute Accessory</h4>
                <div class="price">$8.99</div>
                <div class="quantity">quantity= 100</div>
                <div class="producttype">Product Type: Accessory</div>
                <div class="productsize">Product Size: XS</div>
            </div>
        </div>

        <div class="product-card" data-price="20.99" data-size="XL" data-category="footwear">
            <img src="images/flower5.jpg" alt="Sport Footwear" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect width=%22300%22 height=%22200%22 fill=%22%23f8dddd%22/%3E%3Ctext x=%22150%22 y=%22100%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22%23d12061%22%3ESport Footwear%3C/text%3E%3C/svg%3E'">
            <div class="actions"><div>add</div><div>add to cart</div><div>delete</div></div>
            <div class="info">
                <h4>Sport Footwear</h4>
                <div class="price">$20.99</div>
                <div class="quantity">quantity= 25</div>
                <div class="producttype">Product Type: Footwear</div>
                <div class="productsize">Product Size: XL</div>
            </div>
        </div>

        <div class="product-card" data-price="13.99" data-size="M" data-category="top">
            <img src="images/flower6.jpg" alt="Premium Top" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect width=%22300%22 height=%22200%22 fill=%22%23f8dddd%22/%3E%3Ctext x=%22150%22 y=%22100%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22%23d12061%22%3EPremium Top%3C/text%3E%3C/svg%3E'">
            <div class="actions"><div>add</div><div>&#9829;&#61975; add to cart</div><div>delete</div></div>
            <div class="info">
                <h4>Premium Top</h4>
                <div class="price">$13.99</div>
                <div class="quantity">quantity= 60</div>
                <div class="producttype">Product Type: Top</div>
                <div class="productsize">Product Size: M</div>
            </div>
        </div>
    </div>
</div>

<script src="js/main.js"></script>
</body>
</html>