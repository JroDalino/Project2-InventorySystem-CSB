/* ============================================
   INVENTORY SYSTEM - SHARED SCRIPTS
   NetBeans Java Web Application
   ============================================ */

// ===== SEARCH FUNCTIONALITY =====
function setupSearch(inputId, tableId, columnIndex = null) {
    const input = document.getElementById(inputId);
    if (!input) return;

    input.addEventListener("keyup", function() {
        let filter = this.value.toLowerCase();
        let rows = document.querySelectorAll(`#${tableId} tbody tr, #${tableId} tr:not(:first-child)`);

        rows.forEach(row => {
            let text = columnIndex !== null 
                ? row.cells[columnIndex].textContent.toLowerCase()
                : row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? "" : "none";
        });
    });
}

// ===== SUPPLIER FUNCTIONS =====
function addSupplier() {
    let name = prompt("Supplier name:");
    let contact = prompt("Contact:");
    let email = prompt("Email:");
    let status = prompt("Status (Active/Inactive):");

    if (!name || !contact || !email || !status) return;

    let table = document.querySelector("#supplierTable tbody");
    let row = table.insertRow();
    let id = table.rows.length;

    let statusClass = status.toLowerCase() === 'active' ? 'status-active' : 'status-inactive';

    row.innerHTML = `
        <td>${id}</td>
        <td>${escapeHtml(name)}</td>
        <td>${escapeHtml(contact)}</td>
        <td>${escapeHtml(email)}</td>
        <td><span class="status ${statusClass}">${escapeHtml(status)}</span></td>
        <td>
            <div class="actions">
                <button class="btn btn-edit" onclick="editRow(this)">Edit</button>
                <button class="btn btn-delete" onclick="deleteRow(this)">Delete</button>
            </div>
        </td>
    `;
}

function deleteRow(btn) {
    if (confirm("Delete this supplier?")) {
        btn.closest("tr").remove();
    }
}

function editRow(btn) {
    let row = btn.closest("tr");
    let cells = row.querySelectorAll("td");

    let name = prompt("Edit name:", cells[1].innerText);
    let contact = prompt("Edit contact:", cells[2].innerText);
    let email = prompt("Edit email:", cells[3].innerText);
    let status = prompt("Edit status (Active/Inactive):", cells[4].innerText);

    if (!name || !contact || !email || !status) return;

    let statusClass = status.toLowerCase() === 'active' ? 'status-active' : 'status-inactive';

    cells[1].innerText = name;
    cells[2].innerText = contact;
    cells[3].innerText = email;
    cells[4].innerHTML = `<span class="status ${statusClass}">${escapeHtml(status)}</span>`;
}

// ===== PROFILE FUNCTIONS =====
function editProfile() {
    const fields = document.querySelectorAll("input:not([type='file']), textarea, select");
    const uploadPic = document.getElementById("uploadPic");

    fields.forEach(field => field.disabled = false);
    if (uploadPic) uploadPic.disabled = false;

    showNotification("Edit Mode Enabled!", "info");
}

function saveProfile() {
    const fields = document.querySelectorAll("input:not([type='file']), textarea, select");
    const uploadPic = document.getElementById("uploadPic");

    fields.forEach(field => field.disabled = true);
    if (uploadPic) uploadPic.disabled = true;

    showNotification("Profile Saved!", "success");
}

function setupProfileImagePreview() {
    const uploadPic = document.getElementById("uploadPic");
    if (!uploadPic) return;

    uploadPic.addEventListener("change", function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.getElementById("profileImage");
                if (img) img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });
}

// ===== PRODUCT FILTER & SORT =====
function setupProductFilters() {
    const priceFilter = document.getElementById("priceFilter");
    const sizeFilter = document.getElementById("sizeFilter");
    const categoryFilter = document.getElementById("categoryFilter");
    const cards = document.querySelectorAll(".product-card");
    const container = document.querySelector(".product-grid");

    if (!priceFilter || !container) return;

    function filterProducts() {
        const size = sizeFilter ? sizeFilter.value : "";
        const category = categoryFilter ? categoryFilter.value : "";

        cards.forEach(card => {
            const cardSize = card.dataset.size;
            const cardCategory = card.dataset.category;
            let show = true;
            if (size && cardSize !== size) show = false;
            if (category && cardCategory !== category) show = false;
            card.style.display = show ? "block" : "none";
        });
    }

    function sortProducts() {
        const value = priceFilter.value;
        const cardArray = Array.from(cards);

        cardArray.sort((a, b) => {
            const priceA = parseFloat(a.dataset.price);
            const priceB = parseFloat(b.dataset.price);
            return value === "low-high" ? priceA - priceB : priceB - priceA;
        });

        cardArray.forEach(card => container.appendChild(card));
    }

    if (priceFilter) priceFilter.addEventListener("change", sortProducts);
    if (sizeFilter) sizeFilter.addEventListener("change", filterProducts);
    if (categoryFilter) categoryFilter.addEventListener("change", filterProducts);
}

// ===== UTILITY FUNCTIONS =====
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showNotification(message, type = "info") {
    // Simple notification - can be enhanced with a toast library
    alert(message);
}

// ===== ACTIVE NAVIGATION HIGHLIGHT =====
function highlightActiveNav() {
    const currentPage = window.location.pathname.split('/').pop() || 'dashboard.jsp';
    const links = document.querySelectorAll('.sidebar a');

    links.forEach(link => {
        if (link.getAttribute('href').includes(currentPage)) {
            link.classList.add('active');
        }
    });
}

// ===== INITIALIZE =====
document.addEventListener("DOMContentLoaded", function() {
    highlightActiveNav();
    setupProfileImagePreview();
    setupProductFilters();
});
