<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Orders</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="sidebar">
    <h1>Inventory</h1>
    <a href="dashboard.jsp">Dashboard</a>
    <a href="product.jsp">Product</a>
    <a href="order.jsp">Order</a>
    <a href="supplier.jsp">Supplier</a>
    <a href="profile.jsp">Profile</a>
</div>

<div class="main-content">
    <div class="content-wrapper">
        <div class="header">
            <div class="title">
                <h1>Orders</h1>
            </div>
            <div class="search-box">
                <span>&#128269;</span>
                <input type="text" id="searchInput" placeholder="Search">
            </div>
        </div>

        <h3 class="section-title">Recent Products</h3>
        <table id="productTable">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>Shirt</td><td>399</td><td><span class="status status-active">In Stock</span></td><td>2023-10-01</td></tr>
                <tr><td>Pants</td><td>67</td><td><span class="status status-low">Low Stock</span></td><td>2023-10-02</td></tr>
                <tr><td>Shorts</td><td>269</td><td><span class="status status-active">In Stock</span></td><td>2023-10-03</td></tr>
                <tr><td>Dress</td><td>800</td><td><span class="status status-low">Low Stock</span></td><td>2023-10-04</td></tr>
                <tr><td>Underwear</td><td>100000</td><td><span class="status status-active">In Stock</span></td><td>2023-10-05</td></tr>
                <tr><td>Skirt</td><td>2</td><td><span class="status status-low">Low Stock</span></td><td>2023-10-06</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script src="js/main.js"></script>
<script>
    setupSearch("searchInput", "productTable", 0);
</script>
</body>
</html>