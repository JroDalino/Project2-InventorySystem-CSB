<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Inventory Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="logo">
        <img src="images/bigeyes.webp" alt="Logo" onerror="this.style.display='none'">
    </div>
    <h1>Inventory</h1>
    <a href="dashboard.jsp">Dashboard</a>
    <a href="product.jsp">Product</a>
    <a href="order.jsp">Order</a>
    <a href="supplier.jsp">Supplier</a>
    <a href="profile.jsp">Profile</a>
</div>

<!-- Main Content -->
<div class="main">

    <!-- Header -->
    <div class="header">
        <div class="title">
            <small>Primary</small>
            <h1>Dashboard</h1>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="cards">
        <div class="card one">
            <h3>Total Products</h3>
            <p>120</p>
        </div>
        <div class="card two">
            <h3>Total Stock</h3>
            <p>540</p>
        </div>
        <div class="card three">
            <h3>Pending Orders</h3>
            <p>15</p>
        </div>
        <div class="card four">
            <h3>Total Sales</h3>
            <p>320</p>
        </div>
        <div class="card five">
            <h3>Out of Stock</h3>
            <p>8</p>
        </div>
    </div>

    <!-- Recent Products Table -->
    <div class="table-section">
        <h3>Recent Products</h3>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Stock</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Notebook</td>
                    <td>50</td>
                    <td><span class="status status-active">In Stock</span></td>
                </tr>
                <tr>
                    <td>Ballpen</td>
                    <td>5</td>
                    <td><span class="status status-low">Low Stock</span></td>
                </tr>
            </tbody>
        </table>
    </div>

</div>

<script src="js/main.js"></script>
</body>
</html>