<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>All About Me Profile</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="sidebar">
    <h1>Inventory</h1>
    <a href="dashboard.jsp">Dashboard</a>
    <a href="product.jsp">Product</a>
    <a href="order.jsp">Order</a>
    <a href="supplier.jsp">Supplier</a>
    <a href="profile.jsp">Profile</a>
</div>

<div class="main-content">
    <div class="profile-card">
        <div class="top-bar">
            <div class="top-title">ALL ABOUT ME PROFILE</div>
        </div>

        <div class="profile-content">
            <!-- LEFT SIDE -->
            <div class="profile-left">
                <h2>Hello &#10084;</h2>

                <div class="input-group">
                    <label>My name is</label>
                    <input type="text" placeholder="Enter your name" disabled>
                </div>

                <div class="input-group">
                    <label>I am from</label>
                    <input type="text" placeholder="Enter your location" disabled>
                </div>

                <div class="input-group">
                    <label>I am</label>
                    <input type="number" placeholder="Age" disabled>
                </div>

                <div class="input-group">
                    <label>Personal Information</label>
                    <div class="box">
                        <input type="text" placeholder="Full Name" disabled>
                        <input type="date" disabled>
                        <input type="text" placeholder="Contact Number" disabled>
                        <input type="text" placeholder="Address" disabled>
                        <input type="email" placeholder="Email Address" disabled>
                        <input type="text" placeholder="Company" disabled>
                        <input type="text" placeholder="Role / Position" disabled>
                    </div>
                </div>
            </div>

            <!-- RIGHT SIDE -->
            <div class="profile-right">
                <div class="profile-pic-container">
                    <img src="https://via.placeholder.com/150" id="profileImage" class="profile-pic" 
                         onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22150%22 height=%22150%22%3E%3Crect width=%22150%22 height=%22150%22 fill=%22%23ffd6df%22/%3E%3Ctext x=%2275%22 y=%2280%22 font-size=%2214%22 text-anchor=%22middle%22 fill=%22%23ff7fa1%22%3EAdd Photo%3C/text%3E%3C/svg%3E'">
                    <input type="file" id="uploadPic" accept="image/*" hidden disabled>
                    <button class="change-pic-btn" onclick="document.getElementById('uploadPic').click()">Change Picture</button>
                </div>

                <div class="box">
                    <strong>Gender</strong>
                    <div class="gender-options">
                        <label><input type="radio" name="gender" disabled> Female</label>
                        <label><input type="radio" name="gender" disabled> Male</label>
                        <label><input type="radio" name="gender" disabled> Other</label>
                    </div>
                </div>

                <div class="box">
                    <strong>Bio</strong>
                    <textarea placeholder="Write down your bio here..." disabled></textarea>
                </div>

                <button class="save-btn" onclick="saveProfile()">Save Profile</button>
                <button class="edit-btn" onclick="editProfile()">Edit Profile</button>
            </div>
        </div>

        <div class="footer">www.Allaboutme.com</div>
    </div>
</div>

<script src="js/main.js"></script>
</body>
</html>