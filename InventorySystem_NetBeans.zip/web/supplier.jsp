<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Suppliers</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="sidebar">
    <h1>Inventory</h1>
    <a href="dashboard.jsp">Dashboard</a>
    <a href="product.jsp">Product</a>
    <a href="order.jsp">Order</a>
    <a href="supplier.jsp">Supplier</a>
    <a href="profile.jsp">Profile</a>
</div>

<div class="container">
    <div class="header">
        <div class="title">
            <h1>Supplier List</h1>
        </div>
        <div class="header-actions" style="display: flex; gap: 12px; align-items: center;">
            <div class="search-container">
                <span>&#128269;</span>
                <input type="text" id="searchInput" placeholder="Search supplier..." />
            </div>
            <button class="btn-add" onclick="addSupplier()">
                <span>+</span> Add Supplier
            </button>
        </div>
    </div>

    <div class="table-wrapper">
        <table id="supplierTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Supplier Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>ABC Supplies</td>
                    <td>09123456789</td>
                    <td>abc@email.com</td>
                    <td><span class="status status-active">Active</span></td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-edit" onclick="editRow(this)">Edit</button>
                            <button class="btn btn-delete" onclick="deleteRow(this)">Delete</button>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>XYZ Trading</td>
                    <td>09987654321</td>
                    <td>xyz@email.com</td>
                    <td><span class="status status-inactive">Inactive</span></td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-edit" onclick="editRow(this)">Edit</button>
                            <button class="btn btn-delete" onclick="deleteRow(this)">Delete</button>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Global Goods</td>
                    <td>09112223344</td>
                    <td>global@email.com</td>
                    <td><span class="status status-active">Active</span></td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-edit" onclick="editRow(this)">Edit</button>
                            <button class="btn btn-delete" onclick="deleteRow(this)">Delete</button>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script src="js/main.js"></script>
<script>
    setupSearch("searchInput", "supplierTable");
</script>
</body>
</html>