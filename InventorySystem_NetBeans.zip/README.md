# Inventory System - NetBeans Project

## Project Structure
```
InventorySystem/
├── nbproject/              # NetBeans project configuration
│   ├── project.xml
│   └── project.properties
├── src/
│   ├── java/               # Java source files
│   │   └── inventory/
│   │       └── InventoryServlet.java
│   ├── test/               # Test files
│   └── conf/               # Configuration files
├── web/                    # Web application root
│   ├── css/
│   │   └── style.css       # Shared stylesheet
│   ├── js/
│   │   └── main.js         # Shared JavaScript
│   ├── images/             # Image assets
│   ├── WEB-INF/
│   │   └── web.xml         # Web app configuration
│   ├── dashboard.jsp       # Dashboard page
│   ├── product.jsp         # Products page
│   ├── order.jsp           # Orders page
│   ├── supplier.jsp        # Suppliers page
│   └── profile.jsp         # User profile page
├── build/                  # Build output (generated)
└── dist/                   # Distribution WAR (generated)
```

## How to Run in NetBeans

1. Open NetBeans IDE
2. Go to **File > Open Project**
3. Select the `InventorySystem` folder
4. Right-click the project and select **Run**
5. The application will open in your browser at `http://localhost:8080/InventorySystem/`

## Features
- **Dashboard**: Overview with summary cards and recent products table
- **Products**: Product grid with filtering (price, size, category) and sorting
- **Orders**: Order history with search functionality
- **Suppliers**: Supplier management with add/edit/delete operations
- **Profile**: User profile with edit/save functionality

## Requirements
- JDK 8 or higher
- Apache Tomcat 9+ (bundled with NetBeans)
- NetBeans IDE (Java EE or Full version)

## Notes
- Add your images to `web/images/` folder:
  - `wow.jpg` - Main background
  - `hp.jpg` - Sidebar background
  - `bigeyes.webp` - Logo
  - `flower1.jpg` to `flower6.jpg` - Product images
